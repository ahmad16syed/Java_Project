package com.tns.productservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductService {
	@Autowired
	private ProductRepository repo;
	
	// Get all record from table
	public List<Product> listAll()
	{
		return repo.findAll();
	}
	
	// Saving values to the table
	public void save(Product prod)
	{
		repo.save(prod);
	}
	
	// Get one record with ID
	public Product get(Integer pro_id)
	{
		return repo.findById(pro_id).get();
	}
	
	// Delete one record with ID
	public void delete(Integer pro_id)
	{
		repo.deleteById(pro_id);
	}

}