package com.tns.productservice;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Product {
	
	@Id
	@Column(name="pro_id")
	private int pro_id;
	
	@Column(name="pro_name")
	private String pro_name;
	
	@Column(name="price")
	private float price;
	
	@Column(name="category")
	private String category;
	
	@Column(name="manufacture")
	private LocalDate manufacture;
	
	@Column(name="expiry")
	private LocalDate expiry;
	
	public int getPro_id() {
		return pro_id;
	}
	public void setPro_id(int pro_id) {
		this.pro_id = pro_id;
	}
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public LocalDate getManufacture() {
		return manufacture;
	}
	public void setManufacture(LocalDate manufacture) {
		this.manufacture = manufacture;
	}
	public LocalDate getExpiry() {
		return expiry;
	}
	public void setExpiry(LocalDate expiry) {
		this.expiry = expiry;
	}
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Product(int pro_id, String pro_name, float price, String category, LocalDate manufacture,
			LocalDate expiry) {
		super();
		this.pro_id = pro_id;
		this.pro_name = pro_name;
		this.price = price;
		this.category = category;
		this.manufacture = manufacture;
		this.expiry = expiry;
	}
	
	@Override
	public String toString() {
		return "Product [pro_id=" + pro_id + ", pro_name=" + pro_name + ", price=" + price + ", category=" + category
				+ ", manufacture=" + manufacture + ", expiry=" + expiry + "]";
	}

}