package com.tns.ownerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OwnerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OwnerserviceApplication.class, args);
	}

}
