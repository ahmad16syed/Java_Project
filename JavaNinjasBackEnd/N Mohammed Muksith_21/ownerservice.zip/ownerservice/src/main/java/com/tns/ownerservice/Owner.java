package com.tns.ownerservice;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Owner {
	
	@Id
	@Column(name="owner_id")
	private int owner_id;
	
	@Column(name="owner_name")
	private String owner_name;
	
	@Column(name="owner_dob")
	private LocalDate owner_dob;
	
	
	public int getOwner_id() {
		return owner_id;
	}
	public void setOwner_id(int owner_id) {
		this.owner_id = owner_id;
	}
	public String getOwner_name() {
		return owner_name;
	}
	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}
	public LocalDate getOwner_dob() {
		return owner_dob;
	}
	public void setOwner_dob(LocalDate owner_dob) {
		this.owner_dob = owner_dob;
	}
	
	
	public Owner() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Owner(int owner_id, String owner_name, LocalDate owner_dob) {
		super();
		this.owner_id = owner_id;
		this.owner_name = owner_name;
		this.owner_dob = owner_dob;
	}
	
	@Override
	public String toString() {
		return "Owner [owner_id=" + owner_id + ", owner_name=" + owner_name + ", owner_dob=" + owner_dob + "]";
	}

}
