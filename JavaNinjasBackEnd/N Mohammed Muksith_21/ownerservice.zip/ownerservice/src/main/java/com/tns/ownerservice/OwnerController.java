package com.tns.ownerservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.persistence.NoResultException;

@RestController
public class OwnerController {
	@Autowired
	private OwnerService service;
	
	@GetMapping("/ownerservice")
	public List<Owner> list()
	{
		return service.listAll();
	}
	
	@PostMapping("/ownerservice")
	public void add(@RequestBody Owner owner)
	{
		service.save(owner);
	}
	
	@PutMapping("/ownerservice")
	public ResponseEntity<?> update(@RequestBody Owner owner)
	{
		service.save(owner);
		return new ResponseEntity<Owner>(HttpStatus.OK);
	}
	
	@GetMapping("/ownerservice/{owner_id}")
	public ResponseEntity<Owner> get(@PathVariable Integer owner_id)
	{
		try
		{
			Owner owner = service.get(owner_id);
			return new ResponseEntity<Owner>(owner, HttpStatus.OK);
		}
		catch(NoResultException e)
		{
			return new ResponseEntity<Owner>(HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/ownerservice/{owner_id}")
	public void delete(@PathVariable Integer owner_id)
	{
		service.delete(owner_id);
	}

}