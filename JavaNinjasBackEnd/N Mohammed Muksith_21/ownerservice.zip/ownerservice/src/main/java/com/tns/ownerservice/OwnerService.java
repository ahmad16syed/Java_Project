package com.tns.ownerservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class OwnerService {
	@Autowired
	private OwnerRepository repo;
	
	// Get all records from the table
	public List<Owner> listAll()
	{
		return repo.findAll();
	}
	
	// Saving values to the table
	public void save(Owner owner)
	{
		repo.save(owner);
	}
	
	// Get one record with ID
	public Owner get(Integer pro_id)
	{
		return repo.findById(pro_id).get();
	}
	
	// Delete one record with ID
	public void delete(Integer pro_id)
	{
		repo.deleteById(pro_id);
	}

}
