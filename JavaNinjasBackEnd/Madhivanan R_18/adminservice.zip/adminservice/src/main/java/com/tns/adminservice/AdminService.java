package com.tns.adminservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AdminService {
	@Autowired
	private AdminRepository repo;
	
	// Get all records from the table
	public List<Admin> listAll()
	{
		return repo.findAll();
	}
	
	// Saving values to the table
	public void save(Admin admin)
	{
		repo.save(admin);
	}
	
	// Get one record with ID
	public Admin get(Integer admin_id)
	{
		return repo.findById(admin_id).get();
	}
	
	// Delete one record with ID
	public void delete(Integer admin_id)
	{
		repo.deleteById(admin_id);
	}
}