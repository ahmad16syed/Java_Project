package com.tns.customerservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService {
	@Autowired
	private CustomerRepository repo;
	
	// Get all records from table
	public List<Customer> listAll()
	{
		return repo.findAll();
	}
	
	// Saving values to the table
	public void save(Customer cust)
	{
		repo.save(cust);
	}
	
	// Get one record with ID
	public Customer get(Integer cust_id)
	{
		return repo.findById(cust_id).get();
	}
	
	// Delete one record with ID
	public void delete(Integer cust_id)
	{
		repo.deleteById(cust_id);
	}
}