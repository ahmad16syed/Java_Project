package com.tns.customerservice;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;


@Entity
public class Customer {

	@Id
	@Column(name="cust_id")
	private int cust_id;
	
	@Column(name="cust_name")
	private String cust_name;
	
	@Column(name="ph_no")
	private int ph_no;
	
	@Column(name="email")
	private int email;

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cus_id) {
		this.cust_id = cus_id;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cus_name) {
		this.cust_name = cus_name;
	}

	public int getPh_no() {
		return ph_no;
	}

	public void setPh_no(int ph_no) {
		this.ph_no = ph_no;
	}

	public int getEmail() {
		return email;
	}

	public void setEmail(int email) {
		this.email = email;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int cust_id, String cust_name, int ph_no, int email) {
		super();
		this.cust_id = cust_id;
		this.cust_name = cust_name;
		this.ph_no = ph_no;
		this.email = email;
	}

	@Override
	public String toString() {
		return "Customer [cust_id=" + cust_id + ", cust_name=" + cust_name + ", ph_no=" + ph_no + ", email=" + email + "]";
	}
	
}
