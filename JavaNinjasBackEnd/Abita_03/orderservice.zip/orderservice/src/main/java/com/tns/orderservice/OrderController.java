package com.tns.orderservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.persistence.NoResultException;

@RestController
public class OrderController {
	@Autowired
	private OrderService service;
	
	@GetMapping("/orderservice")
	public List<Order> list()
	{
		return service.listAll();
	}
	
	@PostMapping("/orderservice")
	public void add(@RequestBody Order order)
	{
		service.save(order);
	}
	
	@PutMapping("/orderservice")
	public ResponseEntity<?> update(@RequestBody Order order)
	{
		service.save(order);
		return new ResponseEntity<Order>(HttpStatus.OK);
	}
	
	@GetMapping("/orderservice/{order_id}")
	public ResponseEntity<Order> get(@PathVariable Integer order_id)
	{
		try
		{
			Order order = service.get(order_id);
			return new ResponseEntity<Order>(order, HttpStatus.OK);
		}
		catch(NoResultException e)
		{
			return new ResponseEntity<Order>(HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/orderservice/{order_id}")
	public void delete(@PathVariable Integer order_id)
	{
		service.delete(order_id);
	}
}
