package com.tns.orderservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class OrderService {
	@Autowired
	private OrderRepository repo;
	
	// Get all record from table
	public List<Order> listAll()
	{
		return repo.findAll();
	}
	
	// Saving values to the table
	public void save(Order prod)
	{
		repo.save(prod);
	}
	
	// Get one record with ID
		public Order get(Integer id)
		{
			return repo.findById(id).get();
		}
		
		// Delete one record with ID
		public void delete(Integer id)
		{
			repo.deleteById(id);
		}

	}
