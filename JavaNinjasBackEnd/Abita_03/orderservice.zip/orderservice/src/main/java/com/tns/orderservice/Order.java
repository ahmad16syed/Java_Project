package com.tns.orderservice;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Order{
	
	@Id
	@Column(name="id")
	private int id;
	
	@Column(name="Date_of_purchase")
	private String Date_of_purchase;
	
	@Column(name="Total")
	private Float Total;
	
	@Column(name="Payment_Mode")
	private String Payment_Mode;
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate_of_purchase() {
		return Date_of_purchase;
	}

	public void setDate_of_purchase(String date_of_purchase) {
		Date_of_purchase = date_of_purchase;
	}

	public Float getTotal() {
		return Total;
	}

	public void setTotal(Float total) {
		Total = total;
	}

	public String getPayment_Mode() {
		return Payment_Mode;
	}

	public void setPayment_Mode(String payment_Mode) {
		Payment_Mode = payment_Mode;
	}

	
	

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(int id, String date_of_purchase, Float total, String payment_Mode, String shop_id) {
		super();
		this.id = id;
		Date_of_purchase = date_of_purchase;
		Total = total;
		Payment_Mode = payment_Mode;
		
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", Date_of_purchase=" + Date_of_purchase + ", Total=" + Total + ", Payment_Mode="
				+ Payment_Mode + ", "
						+ "]";
	}

	
	
}
